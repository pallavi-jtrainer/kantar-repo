package com.edforce.sampleproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SampleprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
